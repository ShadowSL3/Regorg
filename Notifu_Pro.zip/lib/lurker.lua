-- lurker hot-reload (mock)
return {}