
local love = love
local lume = require("lib.lume")
local lurker = require("lib.lurker")

local sampleRate = 44100
local bitDepth = 16
local channels = 1

local instruments = {
    sine = function(freq, length)
        local soundData = love.sound.newSoundData(length * sampleRate, sampleRate, bitDepth, channels)
        for i = 0, soundData:getSampleCount() - 1 do
            local t = i / sampleRate
            local sample = math.sin(2 * math.pi * freq * t)
            soundData:setSample(i, sample)
        end
        return soundData
    end
}

local function applyReverb(sd, decay, delaySamples)
    for i = delaySamples, sd:getSampleCount() - 1 do
        local current = sd:getSample(i)
        local delayed = sd:getSample(i - delaySamples)
        sd:setSample(i, current + delayed * decay)
    end
end

function love.load()
    love.window.setTitle("Notifu Pro")
    currentInstrument = "sine"
    notes = {
        {freq = 440, length = 1.0, volume = 1.0, reverb = true}
    }
end

function love.keypressed(key)
    if key == "e" then
        exportWAV()
    end
end

function exportWAV()
    local fullLength = 3 -- seconds
    local mix = love.sound.newSoundData(fullLength * sampleRate, sampleRate, bitDepth, channels)
    for _, note in ipairs(notes) do
        local snd = instruments[currentInstrument](note.freq, note.length)
        if note.reverb then applyReverb(snd, 0.4, 3000) end
        for i = 0, snd:getSampleCount() - 1 do
            local current = mix:getSample(i)
            mix:setSample(i, current + snd:getSample(i) * note.volume)
        end
    end
    love.filesystem.write("export.wav", mix)
    print("WAV esportato!")
end

function love.draw()
    love.graphics.print("Notifu Pro - premi 'E' per esportare WAV", 10, 10)
end
