function love.conf(t)
    t.window.title = "IsoEngine Base"
    t.window.width = 1280
    t.window.height = 720
end