-- Entry point
require 'core.init'