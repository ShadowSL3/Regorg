
function love.conf(t)
    t.identity = "love3d_mobile_demo"
    t.version = "11.5"
    t.console = false
    t.window.title = "Love3D Mobile Demo"
    t.window.width = 800
    t.window.height = 600
    t.modules.joystick = false
    t.modules.physics = false
end
