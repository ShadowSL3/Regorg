function love.conf(t)
    t.window.title = "Latte Supremo"
    t.window.width = 1280
    t.window.height = 720
end