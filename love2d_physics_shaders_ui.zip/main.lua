require("ui")
require("physics")
require("shaders")

function love.load()
    love.window.setTitle("Physics + Shader Demo")
    setupPhysics()
    setupUI()
    setupShaders()
end

function love.update(dt)
    if slowMotion then dt = dt * 0.2 end
    updatePhysics(dt)
end

function love.draw()
    drawFogShader(drawScene)
    drawUI()
end

function drawScene()
    drawPhysics()
end

function love.keypressed(key)
    if key == "i" then
        slowMotion = not slowMotion
    elseif key == "1" then
        toggleShader("fog")
    elseif key == "2" then
        toggleShader("godrays")
    end
end
