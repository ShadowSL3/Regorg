slowMotion = false

function setupUI()
    font = love.graphics.newFont(16)
    love.graphics.setFont(font)
end

function drawUI()
    love.graphics.setColor(0.1, 0.1, 0.1, 0.8)
    love.graphics.rectangle("fill", 0, 0, love.graphics.getWidth(), 30)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("I: Slow Motion | 1: Volumetric Fog | 2: God Rays", 10, 7)
end
