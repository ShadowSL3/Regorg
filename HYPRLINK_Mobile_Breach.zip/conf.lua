function love.conf(t)
    t.window.title = "HYPRLINK: Mobile Breach"
    t.window.resizable = true
    t.window.highdpi = true
    t.console = false
end