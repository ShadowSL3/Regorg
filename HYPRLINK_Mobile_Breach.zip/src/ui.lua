local ui = {}

function ui.load()
    -- Layout responsive
end

function ui.update(dt)
    -- Gestione UI dinamica
end

function ui.draw()
    love.graphics.print("HYPRLINK: Mobile Breach", 20, 20)
end

function ui.resize(w, h)
    -- Adattamento layout
end

return ui