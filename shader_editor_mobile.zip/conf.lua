
function love.conf(t)
    t.identity = "shader_editor_mobile"
    t.version = "11.5"
    t.console = true
    t.window.title = "Shader Editor Mobile"
    t.window.width = 800
    t.window.height = 600
end
