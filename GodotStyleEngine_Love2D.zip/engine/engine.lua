local ui = require("engine.ui.ui")
local editor = require("engine.editor.editor")
local runtime = require("engine.runtime.runtime")

local engine = {}
engine.mode = "editor" -- or 'play'

function engine.load()
    ui.init()
    editor.init()
end

function engine.update(dt)
    if engine.mode == "editor" then
        editor.update(dt)
    else
        runtime.update(dt)
    end
end

function engine.draw()
    if engine.mode == "editor" then
        editor.draw()
    else
        runtime.draw()
    end
end

function engine.mousepressed(x, y, button)
    ui.mousepressed(x, y, button)
end

function engine.mousereleased(x, y, button)
    ui.mousereleased(x, y, button)
end

function engine.keypressed(key)
    if key == "f5" then
        if engine.mode == "editor" then
            engine.mode = "play"
            runtime.start()
        else
            engine.mode = "editor"
            runtime.stop()
        end
    end
end

return engine