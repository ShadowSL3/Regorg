local editor = {}

function editor.init()
    -- Initialize editor tools
end

function editor.update(dt)
end

function editor.draw()
    love.graphics.print("EDITOR MODE", 10, 10)
end

return editor