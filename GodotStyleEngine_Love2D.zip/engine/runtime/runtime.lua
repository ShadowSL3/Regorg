local runtime = {}

function runtime.start()
    -- Load scene and start
end

function runtime.update(dt)
end

function runtime.draw()
    love.graphics.print("PLAY MODE", 10, 10)
end

function runtime.stop()
    -- Cleanup
end

return runtime