love.filesystem.setIdentity("godotstyleengine")

local engine = require("engine.engine")
function love.load()
    engine.load()
end

function love.update(dt)
    engine.update(dt)
end

function love.draw()
    engine.draw()
end

function love.mousepressed(x, y, button)
    engine.mousepressed(x, y, button)
end

function love.mousereleased(x, y, button)
    engine.mousereleased(x, y, button)
end

function love.keypressed(key)
    engine.keypressed(key)
end