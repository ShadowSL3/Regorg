function love.conf(t)
    t.identity = "RockstarEditorLite"
    t.window.title = "Rockstar Editor Mobile"
    t.window.fullscreen = false
    t.window.resizable = true
    t.modules.joystick = false
    t.modules.physics = false
end
