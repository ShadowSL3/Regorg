
#ifndef LUA53_LUTF8LIB_H
#define LUA53_LUTF8LIB_H

#ifdef __cplusplus
extern "C" {
#endif

#include "lua.h"

LUALIB_API int luaopen_luautf8(lua_State *L);

#ifdef __cplusplus
}
#endif

#endif /* LUA53_LUTF8LIB_H */
