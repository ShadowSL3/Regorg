local timer = 30
local maxTimer = 30
local orbit_radius = 100
local center_x, center_y

function love.load()
    center_x, center_y = love.graphics.getWidth() / 2, love.graphics.getHeight() / 2
end

function love.update(dt)
    timer = math.max(0, timer - dt)
end

function love.draw()
    love.graphics.setBackgroundColor(0.1, 0.1, 0.1)

    -- Draw central sun
    love.graphics.setColor(1, 0.8, 0)
    love.graphics.circle("fill", center_x, center_y, 20)

    local segments = math.floor(maxTimer)
    for i = 1, segments do
        local angle = (i / segments) * (2 * math.pi) - math.pi / 2
        local x = center_x + orbit_radius * math.cos(angle)
        local y = center_y + orbit_radius * math.sin(angle)

        if i <= math.floor(timer) then
            love.graphics.setColor(0, 1, 0)
        else
            love.graphics.setColor(0.2, 0.2, 0.2)
        end
        love.graphics.circle("fill", x, y, 6)
    end

    -- Timer text
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf(string.format("Time Left: %.1f", timer), 0, center_y + orbit_radius + 40, love.graphics.getWidth(), "center")
end
