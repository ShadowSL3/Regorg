local ui = {}

function ui.load()
    -- Placeholder for future UI initialization
end

function ui.update(dt)
    -- Placeholder for update logic
end

function ui.draw()
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Animation Editor UI - Coming Soon", 40, 40)
end

function ui.mousepressed(x, y, button)
    -- Placeholder for mouse logic
end

function ui.keypressed(key)
    -- Placeholder for key logic
end

return ui