Love2D Animation Editor (Base Version)
- Import sprite sheet (coming soon)
- Frame-based timeline (WIP)
- Real-time animation preview
- Exports .json animation files

Libraries included:
- Lume
- anim8
- LoveFrames (optional, not yet integrated)

To run:
1. Open with LÖVE 11.x
2. Explore 'ui.lua' for editor expansion
3. Customize and build your timeline

By: ChatGPT + User (2025)