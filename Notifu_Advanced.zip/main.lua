
local lume = require("lib.lume")
local lurker = require("lib.lurker")

function love.load()
    love.window.setTitle("Notifu - Advanced Editor")
    notes = {}
    for i = 1, 16 do
        table.insert(notes, {volume = 1.0, pan = 0.0, reverb = false, length = 0.5})
    end
end

function love.update(dt)
    lurker.update()
end

function love.draw()
    love.graphics.print("Notifu - Editor Avanzato", 10, 10)
    for i, note in ipairs(notes) do
        local x = 10 + i * 30
        local y = 100
        love.graphics.rectangle("line", x, y, 20, -note.volume * 50)
        if note.reverb then
            love.graphics.print("R", x+5, y - 60)
        end
    end
end

function love.mousepressed(x, y, button)
    -- Placeholder per popup editing nota
end
