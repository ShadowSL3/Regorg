
local lurker = {}

function lurker.update() end
function lurker.refresh() end

return lurker
