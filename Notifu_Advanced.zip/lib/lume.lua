
local lume = {}

function lume.clamp(x, min, max)
    return math.max(min, math.min(max, x))
end

return lume
