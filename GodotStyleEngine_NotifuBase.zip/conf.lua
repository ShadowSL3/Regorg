function love.conf(t)
    t.identity = "godotstyleengine"
    t.version = "11.4"
    t.console = true
    t.window.title = "Godot Style Engine"
    t.window.width = 1280
    t.window.height = 720
    t.modules.joystick = false
    t.modules.physics = false
end