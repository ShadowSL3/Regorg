core = require("src.core.core")
editor = require("src.editor.editor")
runtime = require("src.runtime.runtime")
ui = require("src.ui.ui")
nodes = require("src.nodes.nodes")

mode = "editor"

function love.load()
    core.init()
end

function love.update(dt)
    if mode == "editor" then
        editor.update(dt)
    else
        runtime.update(dt)
    end
end

function love.draw()
    if mode == "editor" then
        editor.draw()
    else
        runtime.draw()
    end
end

function love.mousepressed(x, y, button)
    ui.mousepressed(x, y, button)
end

function love.mousereleased(x, y, button)
    ui.mousereleased(x, y, button)
end

function love.keypressed(key)
    if key == "f5" then
        if mode == "editor" then
            runtime.start()
            mode = "play"
        else
            runtime.stop()
            mode = "editor"
        end
    end
end