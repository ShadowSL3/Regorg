local ui = {}

function ui.mousepressed(x, y, button)
end

function ui.mousereleased(x, y, button)
end

return ui