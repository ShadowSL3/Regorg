local nodes = {}

function nodes.createSprite(path)
    return {type = "Sprite", image = love.graphics.newImage(path), x = 0, y = 0}
end

function nodes.createLabel(text)
    return {type = "Label", text = text, x = 0, y = 0}
end

return nodes