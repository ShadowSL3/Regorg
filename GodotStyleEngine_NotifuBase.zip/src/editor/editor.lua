local editor = {}

function editor.update(dt)
    -- Update editor logic
end

function editor.draw()
    love.graphics.print("EDITOR MODE", 10, 10)
end

return editor