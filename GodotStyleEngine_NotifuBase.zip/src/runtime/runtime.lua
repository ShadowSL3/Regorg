local runtime = {}

function runtime.start()
    -- Start runtime scene
end

function runtime.update(dt)
    -- Update runtime scene
end

function runtime.draw()
    love.graphics.print("PLAY MODE", 10, 10)
end

function runtime.stop()
    -- Stop runtime
end

return runtime