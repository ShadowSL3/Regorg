local core = {}

function core.init()
    -- Core Initialization (load assets, setup managers, etc.)
end

return core