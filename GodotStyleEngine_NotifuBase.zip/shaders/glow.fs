extern number time;

vec4 effect(vec4 color, Image texture, vec2 texture_coords, vec2 screen_coords)
{
    vec4 pixel = Texel(texture, texture_coords);
    float glow = abs(sin(time * 2.0));
    return pixel * (1.0 + glow * 0.5);
}